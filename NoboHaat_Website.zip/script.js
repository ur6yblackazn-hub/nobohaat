async function loadProducts() {
  const response = await fetch('products.json');
  const products = await response.json();
  const container = document.getElementById('products');
  container.innerHTML = products.map(p => `
    <div style="border:1px solid #ccc; padding:10px; margin:10px; display:inline-block;">
      <img src="${p.image}" alt="${p.name}" width="150">
      <h3>${p.name}</h3>
      <p>Price: ${p.price}</p>
    </div>
  `).join('');
}
loadProducts();